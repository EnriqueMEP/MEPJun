// ===== USERS MODULE =====
// Módulo de Gestión de Usuarios integrado con MEP-Projects

class UsersModule {
    constructor() {
        this.moduleId = 'users';
        this.currentTab = 'dashboard';
        this.data = {};
        this.isInitialized = false;
        this.users = [];
        this.roles = [];
        this.permissions = [];
        this.groups = [];
        this.auditLogs = [];
        this.filters = {
            search: '',
            role: '',
            status: '',
            department: ''
        };
        this.sortBy = 'name';
        this.sortOrder = 'asc';
        this.currentPage = 1;
        this.itemsPerPage = 25;
    }

    async render(container) {
        try {
            console.log('👥 Renderizando módulo de Usuarios...');

            const usersHTML = `
                <div class="users-module">
                    <!-- Header del módulo -->
                    <div class="module-header">
                        <div class="module-title">
                            <h1>Gestión de Usuarios</h1>
                            <p>Administración de usuarios, roles y permisos</p>
                        </div>
                        <div class="module-actions">
                            <button class="btn btn-secondary" onclick="window.app.modules.users.refreshData()">
                                <i data-lucide="refresh-cw"></i>
                                Actualizar
                            </button>
                            <button class="btn btn-secondary" onclick="window.app.modules.users.exportUsers()">
                                <i data-lucide="download"></i>
                                Exportar
                            </button>
                            <button class="btn btn-primary" onclick="window.app.modules.users.addUser()">
                                <i data-lucide="user-plus"></i>
                                Nuevo Usuario
                            </button>
                        </div>
                    </div>

                    <!-- Navegación por pestañas -->
                    <div class="users-navigation">
                        <nav class="tab-navigation">
                            <button class="tab-btn active" data-tab="dashboard">
                                <i data-lucide="layout-dashboard"></i>
                                Dashboard
                            </button>
                            <button class="tab-btn" data-tab="users">
                                <i data-lucide="users"></i>
                                Usuarios
                            </button>
                            <button class="tab-btn" data-tab="roles">
                                <i data-lucide="shield"></i>
                                Roles
                            </button>
                            <button class="tab-btn" data-tab="permissions">
                                <i data-lucide="key"></i>
                                Permisos
                            </button>
                            <button class="tab-btn" data-tab="groups">
                                <i data-lucide="users-2"></i>
                                Grupos
                            </button>
                            <button class="tab-btn" data-tab="audit">
                                <i data-lucide="file-text"></i>
                                Auditoría
                            </button>
                            <button class="tab-btn" data-tab="security">
                                <i data-lucide="shield-check"></i>
                                Seguridad
                            </button>
                        </nav>
                    </div>

                    <!-- Contenido de las pestañas -->
                    <div class="users-content">
                        <!-- Dashboard Tab -->
                        <div class="tab-panel active" data-panel="dashboard">
                            <div class="users-dashboard">
                                <!-- KPIs principales -->
                                <div class="stats-grid">
                                    <div class="stat-card">
                                        <div class="stat-icon">
                                            <i data-lucide="users"></i>
                                        </div>
                                        <div class="stat-details">
                                            <h3>Total Usuarios</h3>
                                            <div class="stat-value">248</div>
                                            <div class="stat-change positive">+12 este mes</div>
                                        </div>
                                    </div>
                                    <div class="stat-card">
                                        <div class="stat-icon success">
                                            <i data-lucide="user-check"></i>
                                        </div>
                                        <div class="stat-details">
                                            <h3>Usuarios Activos</h3>
                                            <div class="stat-value">234</div>
                                            <div class="stat-change positive">94.4% del total</div>
                                        </div>
                                    </div>
                                    <div class="stat-card">
                                        <div class="stat-icon warning">
                                            <i data-lucide="user-x"></i>
                                        </div>
                                        <div class="stat-details">
                                            <h3>Usuarios Inactivos</h3>
                                            <div class="stat-value">14</div>
                                            <div class="stat-change">Requiere revisión</div>
                                        </div>
                                    </div>
                                    <div class="stat-card">
                                        <div class="stat-icon">
                                            <i data-lucide="shield"></i>
                                        </div>
                                        <div class="stat-details">
                                            <h3>Roles Definidos</h3>
                                            <div class="stat-value">8</div>
                                            <div class="stat-change">5 personalizados</div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Widgets del dashboard -->
                                <div class="dashboard-widgets">
                                    <!-- Widget: Usuarios recientes -->
                                    <div class="widget">
                                        <div class="widget-header">
                                            <h3>Usuarios Recientes</h3>
                                            <button class="btn btn-ghost btn-sm" onclick="window.app.modules.users.switchToTab('users')">Ver todos</button>
                                        </div>
                                        <div class="widget-content">
                                            <div class="recent-users" id="recent-users-list">
                                                <!-- Los usuarios se cargan dinámicamente -->
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Widget: Actividad por rol -->
                                    <div class="widget">
                                        <div class="widget-header">
                                            <h3>Distribución por Roles</h3>
                                            <button class="btn btn-ghost btn-sm" onclick="window.app.modules.users.switchToTab('roles')">Gestionar</button>
                                        </div>
                                        <div class="widget-content">
                                            <div class="role-distribution" id="role-distribution-chart">
                                                <!-- El gráfico se carga dinámicamente -->
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Widget: Actividad reciente -->
                                    <div class="widget">
                                        <div class="widget-header">
                                            <h3>Actividad Reciente</h3>
                                            <button class="btn btn-ghost btn-sm" onclick="window.app.modules.users.switchToTab('audit')">Ver auditoría</button>
                                        </div>
                                        <div class="widget-content">
                                            <div class="recent-activity" id="recent-activity-list">
                                                <!-- La actividad se carga dinámicamente -->
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Widget: Alertas de seguridad -->
                                    <div class="widget">
                                        <div class="widget-header">
                                            <h3>Alertas de Seguridad</h3>
                                            <span class="badge badge-warning">3</span>
                                        </div>
                                        <div class="widget-content">
                                            <div class="security-alerts" id="security-alerts-list">
                                                <!-- Las alertas se cargan dinámicamente -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Users Tab -->
                        <div class="tab-panel" data-panel="users">
                            <div class="users-management">
                                <div class="section-header">
                                    <h2>Gestión de Usuarios</h2>
                                    <div class="section-actions">
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.importUsers()">
                                            <i data-lucide="upload"></i>
                                            Importar
                                        </button>
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.exportUsers()">
                                            <i data-lucide="download"></i>
                                            Exportar
                                        </button>
                                        <button class="btn btn-primary" onclick="window.app.modules.users.addUser()">
                                            <i data-lucide="user-plus"></i>
                                            Nuevo Usuario
                                        </button>
                                    </div>
                                </div>

                                <!-- Filtros y búsqueda -->
                                <div class="users-filters">
                                    <div class="filter-group">
                                        <input type="text" placeholder="Buscar usuarios..." class="search-input" id="user-search">
                                        <select class="filter-select" id="role-filter">
                                            <option value="">Todos los roles</option>
                                        </select>
                                        <select class="filter-select" id="status-filter">
                                            <option value="">Todos los estados</option>
                                            <option value="active">Activos</option>
                                            <option value="inactive">Inactivos</option>
                                            <option value="pending">Pendientes</option>
                                            <option value="suspended">Suspendidos</option>
                                        </select>
                                        <select class="filter-select" id="department-filter">
                                            <option value="">Todos los departamentos</option>
                                        </select>
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.applyFilters()">
                                            <i data-lucide="filter"></i>
                                            Filtrar
                                        </button>
                                        <button class="btn btn-ghost" onclick="window.app.modules.users.clearFilters()">
                                            <i data-lucide="x"></i>
                                            Limpiar
                                        </button>
                                    </div>
                                </div>

                                <!-- Quick stats -->
                                <div class="users-quick-stats" id="users-quick-stats">
                                    <!-- Las estadísticas se cargan dinámicamente -->
                                </div>

                                <!-- Acciones masivas -->
                                <div class="bulk-actions" id="bulk-actions" style="display: none;">
                                    <div class="bulk-actions-content">
                                        <span class="bulk-actions-count">0 usuarios seleccionados</span>
                                        <div class="bulk-actions-buttons">
                                            <button class="btn btn-secondary btn-sm" onclick="window.app.modules.users.bulkActivate()">
                                                <i data-lucide="user-check"></i>
                                                Activar
                                            </button>
                                            <button class="btn btn-secondary btn-sm" onclick="window.app.modules.users.bulkDeactivate()">
                                                <i data-lucide="user-x"></i>
                                                Desactivar
                                            </button>
                                            <button class="btn btn-secondary btn-sm" onclick="window.app.modules.users.bulkChangeRole()">
                                                <i data-lucide="shield"></i>
                                                Cambiar Rol
                                            </button>
                                            <button class="btn btn-secondary btn-sm" onclick="window.app.modules.users.bulkDelete()">
                                                <i data-lucide="trash-2"></i>
                                                Eliminar
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tabla de usuarios -->
                                <div class="users-table">
                                    <div class="table-controls">
                                        <div class="table-controls-left">
                                            <select class="items-per-page" id="items-per-page">
                                                <option value="10">10 por página</option>
                                                <option value="25" selected>25 por página</option>
                                                <option value="50">50 por página</option>
                                                <option value="100">100 por página</option>
                                            </select>
                                        </div>
                                        <div class="table-controls-right">
                                            <button class="btn btn-ghost btn-sm" onclick="window.app.modules.users.toggleView('table')">
                                                <i data-lucide="table"></i>
                                            </button>
                                            <button class="btn btn-ghost btn-sm" onclick="window.app.modules.users.toggleView('grid')">
                                                <i data-lucide="grid-3x3"></i>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <table class="data-table" id="users-table">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <input type="checkbox" id="select-all-users">
                                                </th>
                                                <th class="sortable" data-sort="name">
                                                    Usuario
                                                    <i data-lucide="chevron-up-down"></i>
                                                </th>
                                                <th class="sortable" data-sort="email">
                                                    Email
                                                    <i data-lucide="chevron-up-down"></i>
                                                </th>
                                                <th class="sortable" data-sort="role">
                                                    Rol
                                                    <i data-lucide="chevron-up-down"></i>
                                                </th>
                                                <th class="sortable" data-sort="department">
                                                    Departamento
                                                    <i data-lucide="chevron-up-down"></i>
                                                </th>
                                                <th class="sortable" data-sort="status">
                                                    Estado
                                                    <i data-lucide="chevron-up-down"></i>
                                                </th>
                                                <th class="sortable" data-sort="lastLogin">
                                                    Último Acceso
                                                    <i data-lucide="chevron-up-down"></i>
                                                </th>
                                                <th class="sortable" data-sort="created">
                                                    Fecha Registro
                                                    <i data-lucide="chevron-up-down"></i>
                                                </th>
                                                <th>Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody id="users-tbody">
                                            <!-- Los usuarios se cargan dinámicamente -->
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Paginación -->
                                <div class="pagination" id="users-pagination">
                                    <!-- La paginación se genera dinámicamente -->
                                </div>
                            </div>
                        </div>

                        <!-- Roles Tab -->
                        <div class="tab-panel" data-panel="roles">
                            <div class="roles-management">
                                <div class="section-header">
                                    <h2>Gestión de Roles</h2>
                                    <div class="section-actions">
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.exportRoles()">
                                            <i data-lucide="download"></i>
                                            Exportar
                                        </button>
                                        <button class="btn btn-primary" onclick="window.app.modules.users.addRole()">
                                            <i data-lucide="plus"></i>
                                            Nuevo Rol
                                        </button>
                                    </div>
                                </div>

                                <!-- Grid de roles -->
                                <div class="roles-grid" id="roles-grid">
                                    <!-- Los roles se cargan dinámicamente -->
                                </div>
                            </div>
                        </div>

                        <!-- Permissions Tab -->
                        <div class="tab-panel" data-panel="permissions">
                            <div class="permissions-management">
                                <div class="section-header">
                                    <h2>Gestión de Permisos</h2>
                                    <div class="section-actions">
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.resetPermissions()">
                                            <i data-lucide="refresh-cw"></i>
                                            Resetear
                                        </button>
                                        <button class="btn btn-primary" onclick="window.app.modules.users.addPermission()">
                                            <i data-lucide="plus"></i>
                                            Nuevo Permiso
                                        </button>
                                    </div>
                                </div>

                                <!-- Matriz de permisos -->
                                <div class="permissions-matrix" id="permissions-matrix">
                                    <!-- La matriz se carga dinámicamente -->
                                </div>
                            </div>
                        </div>

                        <!-- Groups Tab -->
                        <div class="tab-panel" data-panel="groups">
                            <div class="groups-management">
                                <div class="section-header">
                                    <h2>Gestión de Grupos</h2>
                                    <div class="section-actions">
                                        <button class="btn btn-primary" onclick="window.app.modules.users.addGroup()">
                                            <i data-lucide="plus"></i>
                                            Nuevo Grupo
                                        </button>
                                    </div>
                                </div>

                                <!-- Lista de grupos -->
                                <div class="groups-list" id="groups-list">
                                    <!-- Los grupos se cargan dinámicamente -->
                                </div>
                            </div>
                        </div>

                        <!-- Audit Tab -->
                        <div class="tab-panel" data-panel="audit">
                            <div class="audit-management">
                                <div class="section-header">
                                    <h2>Auditoría de Usuarios</h2>
                                    <div class="section-actions">
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.exportAuditLog()">
                                            <i data-lucide="download"></i>
                                            Exportar Log
                                        </button>
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.clearOldLogs()">
                                            <i data-lucide="trash-2"></i>
                                            Limpiar Antiguos
                                        </button>
                                    </div>
                                </div>

                                <!-- Filtros de auditoría -->
                                <div class="audit-filters">
                                    <div class="filter-group">
                                        <input type="date" class="filter-input" id="audit-date-from" placeholder="Desde">
                                        <input type="date" class="filter-input" id="audit-date-to" placeholder="Hasta">
                                        <select class="filter-select" id="audit-action-filter">
                                            <option value="">Todas las acciones</option>
                                            <option value="login">Inicio de sesión</option>
                                            <option value="logout">Cierre de sesión</option>
                                            <option value="create">Creación</option>
                                            <option value="update">Actualización</option>
                                            <option value="delete">Eliminación</option>
                                            <option value="permission">Cambio de permisos</option>
                                        </select>
                                        <select class="filter-select" id="audit-user-filter">
                                            <option value="">Todos los usuarios</option>
                                        </select>
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.applyAuditFilters()">
                                            <i data-lucide="filter"></i>
                                            Filtrar
                                        </button>
                                    </div>
                                </div>

                                <!-- Tabla de auditoría -->
                                <div class="audit-table">
                                    <table class="data-table">
                                        <thead>
                                            <tr>
                                                <th>Fecha/Hora</th>
                                                <th>Usuario</th>
                                                <th>Acción</th>
                                                <th>Objetivo</th>
                                                <th>IP</th>
                                                <th>Dispositivo</th>
                                                <th>Estado</th>
                                                <th>Detalles</th>
                                            </tr>
                                        </thead>
                                        <tbody id="audit-tbody">
                                            <!-- Los logs se cargan dinámicamente -->
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Paginación de auditoría -->
                                <div class="pagination" id="audit-pagination">
                                    <!-- La paginación se genera dinámicamente -->
                                </div>
                            </div>
                        </div>

                        <!-- Security Tab -->
                        <div class="tab-panel" data-panel="security">
                            <div class="security-management">
                                <div class="section-header">
                                    <h2>Configuración de Seguridad</h2>
                                    <div class="section-actions">
                                        <button class="btn btn-secondary" onclick="window.app.modules.users.generateSecurityReport()">
                                            <i data-lucide="file-text"></i>
                                            Informe de Seguridad
                                        </button>
                                        <button class="btn btn-primary" onclick="window.app.modules.users.saveSecuritySettings()">
                                            <i data-lucide="save"></i>
                                            Guardar Configuración
                                        </button>
                                    </div>
                                </div>

                                <!-- Configuración de seguridad -->
                                <div class="security-settings">
                                    <div class="settings-grid">
                                        <!-- Políticas de contraseña -->
                                        <div class="settings-card">
                                            <div class="settings-header">
                                                <h3>Políticas de Contraseña</h3>
                                                <i data-lucide="lock"></i>
                                            </div>
                                            <div class="settings-content">
                                                <div class="setting-item">
                                                    <label class="setting-label">Longitud mínima</label>
                                                    <input type="number" class="setting-input" value="8" min="6" max="32">
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Requiere mayúsculas</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="require-uppercase" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Requiere números</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="require-numbers" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Requiere símbolos</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="require-symbols">
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Caducidad (días)</label>
                                                    <input type="number" class="setting-input" value="90" min="0" max="365">
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Configuración de sesión -->
                                        <div class="settings-card">
                                            <div class="settings-header">
                                                <h3>Gestión de Sesiones</h3>
                                                <i data-lucide="clock"></i>
                                            </div>
                                            <div class="settings-content">
                                                <div class="setting-item">
                                                    <label class="setting-label">Tiempo de sesión (minutos)</label>
                                                    <input type="number" class="setting-input" value="480" min="30" max="1440">
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Múltiples sesiones</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="allow-multiple-sessions" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Recordar dispositivo</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="remember-device" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Intentos fallidos máximos</label>
                                                    <input type="number" class="setting-input" value="5" min="3" max="10">
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Bloqueo temporal (minutos)</label>
                                                    <input type="number" class="setting-input" value="15" min="5" max="60">
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Autenticación de dos factores -->
                                        <div class="settings-card">
                                            <div class="settings-header">
                                                <h3>Autenticación de Dos Factores</h3>
                                                <i data-lucide="shield-check"></i>
                                            </div>
                                            <div class="settings-content">
                                                <div class="setting-item">
                                                    <label class="setting-label">Habilitar 2FA</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="enable-2fa">
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">2FA obligatorio para administradores</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="require-2fa-admin" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Método preferido</label>
                                                    <select class="setting-select">
                                                        <option value="app">Aplicación móvil</option>
                                                        <option value="sms">SMS</option>
                                                        <option value="email">Email</option>
                                                    </select>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Códigos de respaldo</label>
                                                    <button class="btn btn-secondary btn-sm">Generar Códigos</button>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Configuración de auditoría -->
                                        <div class="settings-card">
                                            <div class="settings-header">
                                                <h3>Auditoría y Logs</h3>
                                                <i data-lucide="file-text"></i>
                                            </div>
                                            <div class="settings-content">
                                                <div class="setting-item">
                                                    <label class="setting-label">Registrar inicios de sesión</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="log-logins" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Registrar cambios de datos</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="log-data-changes" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Registrar accesos a archivos</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="log-file-access">
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Retención de logs (días)</label>
                                                    <input type="number" class="setting-input" value="365" min="30" max="2555">
                                                </div>
                                                <div class="setting-item">
                                                    <label class="setting-label">Alertas de seguridad por email</label>
                                                    <div class="switch">
                                                        <input type="checkbox" id="security-email-alerts" checked>
                                                        <span class="slider"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            container.innerHTML = usersHTML;
            this.isInitialized = true;

        } catch (error) {
            console.error('❌ Error renderizando módulo de Usuarios:', error);